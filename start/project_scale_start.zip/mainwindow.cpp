// mainwindow.cpp - DPI-aware additions for scale_test4.ui
// Add these methods to your existing MainWindow class

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFontMetrics>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Apply DPI-aware sizing to all widgets
    applyDpiAwareSizes();

    // Set DPI-aware initial window size
    QFontMetrics fm(QApplication::font());
    int em = fm.height();
    resize(em * 90, em * 50);  // Approximately 90em × 50em
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::applyDpiAwareSizes()
{
    // Get base unit for DPI-aware sizing
    QFontMetrics fm(QApplication::font());
    int em = fm.height();  // Height of one line of text in current font

    // ========================================
    // System Configuration Group
    // ========================================

    // Config Identifier combo box
    ui->comboBox->setMaximumWidth(em * 20);

    // Platform Type combo box
    ui->comboBox_2->setMaximumWidth(em * 30);

    // Config Description text edit
    ui->textEdit->setMinimumHeight(em * 5);  // At least 5 lines tall

    // Buttons - set minimum height for better appearance
    ui->pushButton->setMinimumHeight(em * 2);    // Import Config
    ui->pushButton_2->setMinimumHeight(em * 2);  // Last UDM Upload
    ui->pushButton_3->setMinimumHeight(em * 2);  // Export Config
    ui->pushButton_4->setMinimumHeight(em * 2);  // Save as New Config Identifier
    ui->pushButton_5->setMinimumHeight(em * 2);  // Update Config Identifier
    ui->pushButton_6->setMinimumHeight(em * 2);  // Config Description

    // ========================================
    // Sensor Parameters - Orientation
    // ========================================

    // Yaw, Pitch, Roll line edits
    ui->lineEdit->setMinimumWidth(em * 8);
    ui->lineEdit->setMaximumWidth(em * 10);

    ui->lineEdit_2->setMinimumWidth(em * 8);
    ui->lineEdit_2->setMaximumWidth(em * 10);

    ui->lineEdit_3->setMinimumWidth(em * 8);
    ui->lineEdit_3->setMaximumWidth(em * 10);

    // ========================================
    // Sensor Parameters - Position
    // ========================================

    // x, y, z position line edits
    ui->lineEdit_4->setMinimumWidth(em * 8);
    ui->lineEdit_4->setMaximumWidth(em * 10);

    ui->lineEdit_5->setMinimumWidth(em * 8);
    ui->lineEdit_5->setMaximumWidth(em * 10);

    ui->lineEdit_6->setMinimumWidth(em * 8);
    ui->lineEdit_6->setMaximumWidth(em * 10);

    // Enabled/Disabled combo box
    ui->comboBox_3->setMaximumWidth(em * 12);

    // Sensor buttons
    ui->pushButton_7->setMinimumHeight(em * 2);  // Update Sensor Parameters
    ui->pushButton_8->setMinimumHeight(em * 2);  // Obscuration Maps

    // ========================================
    // System Parameters Group
    // ========================================

    // New Data Source Type
    ui->comboBox_4->setMaximumWidth(em * 15);

    // New Timing Scheme
    ui->comboBox_5->setMaximumWidth(em * 30);

    // New Data FID
    ui->lineEdit_7->setMinimumWidth(em * 10);
    ui->lineEdit_7->setMaximumWidth(em * 12);

    // 1PPS Polarity
    ui->comboBox_6->setMaximumWidth(em * 15);

    // WoW Availability
    ui->comboBox_7->setMaximumWidth(em * 15);

    // Height of Platform Datum
    ui->lineEdit_8->setMinimumWidth(em * 10);
    ui->lineEdit_8->setMaximumWidth(em * 12);

    // ========================================
    // Window Size Constraints
    // ========================================

    // Set minimum window size to prevent it from being too small
    setMinimumSize(em * 70, em * 40);

    // Optional: Set maximum size if you want to limit window size
    // setMaximumSize(em * 120, em * 70);
}

// Optional: If you want to update sizes when font changes
void MainWindow::changeEvent(QEvent *event)
{
    QMainWindow::changeEvent(event);

    if (event->type() == QEvent::FontChange) {
        // Reapply sizes if font changes
        applyDpiAwareSizes();
    }
}

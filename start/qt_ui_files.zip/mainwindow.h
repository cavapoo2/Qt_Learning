#pragma once

#include <QtWidgets/QMainWindow>
#include <QUiLoader>
#include <QWidget>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(const QString& uiFile, QWidget* parent = nullptr);
    ~MainWindow();

    bool loadUiFile(const QString& uiFile);

private:
    QWidget* m_loadedWidget = nullptr;
};

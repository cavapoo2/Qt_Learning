# UIViewer

A Qt6.7 C++ application that loads and displays any `.ui` file passed via command line.
Built for Windows 11 with Visual Studio 2022.

## Requirements

- Qt 6.7.x (msvc2022_64 build)
- Visual Studio 2022
- CMake 3.20+
- Qt VS Tools extension (optional but recommended)

## Setup

### 1. Adjust the Qt path in CMakeLists.txt

Open `CMakeLists.txt` and update this line to match your Qt installation:

```cmake
set(CMAKE_PREFIX_PATH "C:/Qt/6.7.2/msvc2022_64")
```

### 2. Build with CMake (recommended)

```bash
mkdir build
cd build
cmake .. -G "Visual Studio 17 2022" -A x64
cmake --build . --config Release
```

Or open Visual Studio 2022, choose **Open a local folder**, select the project
folder, and Visual Studio will detect the CMakeLists.txt automatically.

### 3. Build with Qt VS Tools (.pro alternative)

If you prefer a .pro file, create `UIViewer.pro`:

```
QT += core gui widgets uitools
CONFIG += c++17
SOURCES += main.cpp mainwindow.cpp
HEADERS += mainwindow.h
TARGET = UIViewer
TEMPLATE = app
```

Then open it with Qt VS Tools.

## Usage

Run from command line:

```
UIViewer.exe <path_to_ui_file>
```

Examples:

```
UIViewer.exe C:\MyProject\forms\mainform.ui
UIViewer.exe ..\ui\settings.ui
```

- The UI file is loaded at runtime using `QUiLoader` — no recompilation needed
- The window wraps the loaded UI in a scroll area so large forms are still navigable
- The window title shows the loaded file path

## Important Note on QUiLoader

`QUiLoader` is part of the `Qt::UiTools` module. Make sure this is installed
with your Qt installation. In the Qt online installer, it is under:
**Qt 6.7.x → Additional Libraries → Qt UI Tools**

## Switching Between UI Files

Simply run the app again with a different file path:

```
UIViewer.exe form1.ui
UIViewer.exe form2.ui
UIViewer.exe form3.ui
```

You can create batch files or shortcuts for each UI file for quick access.

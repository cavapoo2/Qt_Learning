#include "mainwindow.h"

#include <QtWidgets/QApplication>
#include <QCommandLineParser>
#include <QFileInfo>
#include <QMessageBox>
#include <QDebug>

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    app.setApplicationName("UIViewer");
    app.setApplicationVersion("1.0");

    QCommandLineParser parser;
    parser.setApplicationDescription(
        "Qt UI File Viewer - loads and displays a .ui file in a main window.\n"
        "Usage: UIViewer <path_to_ui_file>"
    );
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addPositionalArgument("uifile", "Path to the .ui file to display.");

    parser.process(app);

    const QStringList args = parser.positionalArguments();

    QString uiFilePath;

    if (args.isEmpty())
    {
        // No argument supplied - show usage hint
        QMessageBox::information(nullptr, "UI Viewer",
            "Usage: UIViewer.exe <path_to_ui_file>\n\n"
            "Example:\n  UIViewer.exe C:\\MyProject\\mainform.ui");
        return 0;
    }
    else
    {
        uiFilePath = args.first();
    }

    // Validate the file exists and is a .ui file
    QFileInfo fi(uiFilePath);
    if (!fi.exists())
    {
        QMessageBox::critical(nullptr, "UI Viewer",
            QString("File not found:\n%1").arg(uiFilePath));
        return 1;
    }
    if (fi.suffix().toLower() != "ui")
    {
        QMessageBox::warning(nullptr, "UI Viewer",
            QString("Warning: file does not have a .ui extension:\n%1\n\nAttempting to load anyway.")
            .arg(uiFilePath));
    }

    MainWindow w(uiFilePath);
    w.show();

    return app.exec();
}

#include "mainwindow.h"

#include <QUiLoader>
#include <QFile>
#include <QMessageBox>
#include <QScrollArea>

MainWindow::MainWindow(const QString& uiFile, QWidget* parent)
    : QMainWindow(parent)
{
    setWindowTitle("UI Viewer");
    resize(1024, 768);

    if (!uiFile.isEmpty())
    {
        if (!loadUiFile(uiFile))
        {
            QMessageBox::critical(this, "Error",
                QString("Failed to load UI file:\n%1").arg(uiFile));
        }
    }
}

MainWindow::~MainWindow()
{
}

bool MainWindow::loadUiFile(const QString& uiFile)
{
    QFile file(uiFile);
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::critical(this, "Error",
            QString("Cannot open file:\n%1").arg(uiFile));
        return false;
    }

    QUiLoader loader;
    QWidget* widget = loader.load(&file, this);
    file.close();

    if (!widget)
    {
        QMessageBox::critical(this, "Error",
            QString("Failed to parse UI file:\n%1\n\n%2")
            .arg(uiFile)
            .arg(loader.errorString()));
        return false;
    }

    // Remove previous widget if any
    if (m_loadedWidget)
    {
        delete m_loadedWidget;
        m_loadedWidget = nullptr;
    }

    // Wrap in a scroll area so large UIs are still navigable
    QScrollArea* scrollArea = new QScrollArea(this);
    scrollArea->setWidget(widget);
    scrollArea->setWidgetResizable(true);

    setCentralWidget(scrollArea);
    m_loadedWidget = scrollArea;

    setWindowTitle(QString("UI Viewer - %1").arg(uiFile));

    return true;
}

# Implementation Guide for scale_test4.ui DPI Scaling

## Files You Need

1. **scale_test4_FIXED.ui** - The corrected UI file (already provided)
2. **mainwindow_scale_test4.h** - Header file with method declarations (just created)
3. **mainwindow_scale_test4.cpp** - Implementation file with DPI code (just created)

---

## How to Integrate Into Your Project

### Option 1: If You're Starting Fresh

Simply use the provided files as-is:

1. Use `scale_test4_FIXED.ui` as your UI file
2. Use `mainwindow_scale_test4.h` as your header
3. Use `mainwindow_scale_test4.cpp` as your implementation

**Done!** The DPI scaling is already implemented.

---

### Option 2: If You Have Existing MainWindow Files

Add the new code to your existing files:

#### Step 1: Update mainwindow.h

Add these lines to your **existing** `mainwindow.h`:

```cpp
// In the private section of your MainWindow class:
private:
    void applyDpiAwareSizes();  // ← Add this line

// In the protected section (optional):
protected:
    void changeEvent(QEvent *event) override;  // ← Add if you want font change handling
```

#### Step 2: Update mainwindow.cpp

**Add the include:**
```cpp
#include <QFontMetrics>  // ← Add this at the top with other includes
```

**Modify your constructor:**
```cpp
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    
    // ← Add these lines:
    applyDpiAwareSizes();
    
    QFontMetrics fm(QApplication::font());
    int em = fm.height();
    resize(em * 90, em * 50);
    // ← End of additions
}
```

**Add the applyDpiAwareSizes() method:**

Copy the entire `applyDpiAwareSizes()` method from `mainwindow_scale_test4.cpp` into your existing `mainwindow.cpp` file.

**Optionally add changeEvent():**

Copy the `changeEvent()` method if you want dynamic font change handling.

---

## What Each File Does

### mainwindow_scale_test4.h
- Declares the `applyDpiAwareSizes()` method
- Declares the optional `changeEvent()` override
- Standard MainWindow class structure

### mainwindow_scale_test4.cpp
Contains three key methods:

1. **Constructor** - Sets up the UI and applies DPI sizing
2. **applyDpiAwareSizes()** - Applies DPI-aware constraints to all widgets:
   - Sets maximum widths for combo boxes and line edits
   - Sets minimum heights for buttons
   - Sets minimum/maximum window size
3. **changeEvent()** (optional) - Reapplies sizing if the font changes

---

## Testing Your Implementation

After integrating the code:

### 1. Compile and Run
```bash
qmake
make
./yourapp
```

### 2. Test at Different DPI Settings

**Linux:**
```bash
QT_SCALE_FACTOR=1.0 ./yourapp
QT_SCALE_FACTOR=1.5 ./yourapp
QT_SCALE_FACTOR=2.0 ./yourapp
```

**Windows:**
```cmd
set QT_SCALE_FACTOR=1.0 && yourapp.exe
set QT_SCALE_FACTOR=1.5 && yourapp.exe
set QT_SCALE_FACTOR=2.0 && yourapp.exe
```

### 3. What to Check

At each DPI setting, verify:
- ✅ Window opens at appropriate size
- ✅ All text is readable
- ✅ Line edits are not too wide or too narrow
- ✅ Buttons have good proportions
- ✅ No widgets overlap
- ✅ No text is cut off
- ✅ Window can resize properly
- ✅ Everything looks proportionally correct

---

## Customizing the Sizing

If you want to adjust the sizes, modify the `em` multipliers in `applyDpiAwareSizes()`:

```cpp
// Example: Make combo boxes wider
ui->comboBox->setMaximumWidth(em * 25);  // Was em * 20

// Example: Make line edits smaller
ui->lineEdit->setMaximumWidth(em * 8);   // Was em * 10

// Example: Make buttons taller
ui->pushButton->setMinimumHeight(em * 2.5);  // Was em * 2

// Example: Change window size
resize(em * 100, em * 60);  // Was em * 90, em * 50
```

**The formula:** `em` = height of one line of text at current DPI

- `em * 10` ≈ 10 characters wide
- `em * 2` ≈ 2 lines tall

---

## Widget Sizing Reference

Here's what was set for each widget type:

| Widget | Setting | Value | Purpose |
|--------|---------|-------|---------|
| **Combo boxes** | maxWidth | 15-30em | Prevents too-wide dropdowns |
| **Line edits** | min/maxWidth | 8-12em | Constrains numeric fields |
| **Text edit** | minHeight | 5em | At least 5 lines visible |
| **Buttons** | minHeight | 2em | Good clickable area |
| **Window** | minSize | 70×40em | Prevents too-small window |
| **Window** | initial | 90×50em | Nice starting size |

---

## Troubleshooting

### Issue: Compiler errors about QFontMetrics

**Fix:** Add `#include <QFontMetrics>` at the top of mainwindow.cpp

### Issue: 'applyDpiAwareSizes' is not declared

**Fix:** Add the method declaration to mainwindow.h in the private section

### Issue: ui->comboBox not found

**Fix:** Make sure you're using the fixed UI file (scale_test4_FIXED.ui) and rebuild

### Issue: Window is too small/large

**Fix:** Adjust the multipliers in the `resize()` call:
```cpp
resize(em * 90, em * 50);  // Make these numbers bigger or smaller
```

---

## Summary

**Quick Integration (3 steps):**

1. Replace your `.ui` file with `scale_test4_FIXED.ui`
2. Add `applyDpiAwareSizes()` declaration to your header
3. Add the implementation to your .cpp file and call it from constructor

**Result:** Full DPI scaling support! 🎯

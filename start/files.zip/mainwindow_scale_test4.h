// mainwindow.h - Header file additions for scale_test4.ui
// Add these declarations to your existing MainWindow class

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    // Optional: Handle font changes for dynamic DPI adjustment
    void changeEvent(QEvent *event) override;

private:
    Ui::MainWindow *ui;
    
    // DPI-aware sizing method
    void applyDpiAwareSizes();
};

#endif // MAINWINDOW_H
